<!DOCTYPE html >
<html>
<head>
	<?php $title = "Contact Ekklesia Coffee Co." ; ?>

	<script type="text/javascript" src="random.js"></script>
	<script>
	function showImg() {
	/* The showImg() function displays a random image from the 0.jpg through 9.jpg files.
	The random image is designed to thwart spammers attempting to use the form to send
	junk mail by requiring visual confirmation.
	*/
	var imgNumber=randomInteger(9); //Return a random number from 0 to 9
	document.write("<img src= '"+ imgNumber +".jpg' alt=''/>");
	}
	
	</script>
<!-- Styles -->

<style type="text/css">


fieldset {
	background-color: #FFFBF3;
	border-color: #894828;
	padding: 10px;
	margin-bottom: 10px;
}

fieldset span {
	color: red;
}

label.blockLabel {
	display: block;
	position: relative;
	margin: 12px 0px 12px 0px;
	width: 450px;
	
}


.blockLabel input{
	position:absolute;
	left: 140px;
	
}


#fName, #lName {
	width: 250px;
}


#email, #street {
	width: 350px;
}

#phone, #city {
	width: 150px;
}

#state {
	width: 40px;
}


#zip {
	width: 80px;
}


#mailingList {
	width: 450px;
	padding: 5px;
}

fieldset #interestFields {
	width: 450px;
	height: 120px;
	padding: 5px;
	position: relative;
}

 

#interestFields label {
	position: absolute;
}

#interest1, #interest2, #interest3 {
	top: 20px;
}

#interest4, #interest5, #interest6 {
	top: 50px;
}

#interest7, #interest8, #interest9 {
	top: 80px;
}


#interest1, #interest4, #interest7 {
	left: 0px;
}

#interest2, #interest5, #interest8 {
	left: 140px;
}


#interest3, #interest6, #interest9 {
	left: 280px;
} 


</style>

	<?php require("proj1/header.inc.php");?>
    <?php require("proj1/menu.inc.php");?>

<div id="content">
	<form name="contactForm" id="contactForm" method="post" action="form_process.php" >
	
	<h2>Contact Us</h2>
	<p>* Indicates a required field</p>
	
	<fieldset id="contactFields">
		<legend>Contact Information</legend>
			<label class="blockLabel" for="fName">First Name <span>*</span> 
			<input name="fName" id="fName" type="text" required ="required"> </label>
			
			
			<label class="blockLabel" for="lName">Last Name <span>*</span> 
			<input name="lName" id="lName" type="text" required ="required"> </label>
			
			
			<label class="blockLabel" for="email">Email Address <span>*</span> 
			<input name="email" id="email" type="email" required ="required"></label>
			
			<label class="blockLabel" for="street">Street Address
			<input name="street" id="street" type="text"> </label>
			
			<label class="blockLabel" for="city">City
			<input name="city" id="city" type="text" value="Denver"> </label>
			
			<label class="blockLabel" for="state">State
			<input name="state" id="state" type="text" value="CO" maxlength="2"> </label>
			
			<label class="blockLabel" for="zip">ZIP
			<input name="zip" id="zip" type="text" maxlength="10"> </label>
			
			<label class="blockLabel" for="phone">Phone
			<input name="phone" id="phone" type="tel"> </label>
			
	
	</fieldset>
	
	<fieldset id="otherInfo">
	<legend>Other Tidbits</legend>
		<label class="blockLabel" for="infoSource">How did you hear about Ekklesia Coffee Co?</label>
		<select name="infoSource" id="infoSource">
			<option value="talk">Word of Mouth</option>
			<option value="ads">TV or Radio Ad</option>
			<option value="internet">The Internet</option>
			<option value="phonebook">The Phonebook</option>
			<option value="schools">College/High School</option>x

		</select>
		
	<fieldset id="mailingList">
	<legend>Do you want to be on our mailing list?</legend>
	
		<label for="mYes">Yes</label>
		<input type="radio" name="mList" id="mYes" value="yes"/>
		
		<label for="mNo">No</label>
		<input type="radio" name="mList" id="mNo" value="no"/>

	
	</fieldset> <!-- end mailing list set-->
	
	<fieldset id="interestFields">
	<legend>I want information on (check all that apply)</legend>
	
		<label id="interest1" for="roast">
			<input type="checkbox" name="roast">
			Current Roast
		</label>
		
		<label id="interest2" for="allergy">
			<input type="checkbox" name="allergy">
			Allergy Information
		</label>
		
		<label id="interest3" for="bulk">
			<input type="checkbox" name="bulk">
			Bulk Orders
		</label>
		
		<label id="interest4" for="brew">
			<input type="checkbox" name="brew">
			Brewing Instructions
		</label>
		
		<label id="interest5" for="fees">
			<input type="checkbox" name="fees">
			Delivery Fees
		</label>
		
		<label id="interest6" for="cater">
			<input type="checkbox" name="cater">
			Catering
		</label>
		
		<label id="interest7" for="special">
			<input type="checkbox" name="special">
			Special Orders
		</label>
		
		<label id="interest8" for="storage">
			<input type="checkbox" name="storage">
			Coffee Storage
		</label>
		
		<label id="interest9" for="loyalty">
			<input type="checkbox" name="loyalty">
			Loyalty Program
		</label>
		
	
	</fieldset> <!--end Interest fields-->
	
	
	<label class="blockLabel" for="questions">Questions? We'd love to answer.</label>
	<textarea name="questions" id="questions" rows="5" cols="55"></textarea>

	
	</fieldset> <!-- end other Info field set-->
	<p>
		<label id="captcha" for="captcha">As a final security check, enter the 5 numbers you see displayed below.</label>
		 <br/>
		<input type="text" id="captcha" size="6">
		
	</p>
	<script>
	showImg();
	showImg();
	showImg();
	showImg();
	showImg();

	</script>
	<br/>
	<p>
		<input type="submit" value="Submit Question"/>
		<input type="reset" value="Cancel"/>
	</p>
	
	</form>
	
</div> <!-- end content-->

<?php require("proj1/footer.inc.php");?>
</div> <!-- end layout -->
</body>

</html>