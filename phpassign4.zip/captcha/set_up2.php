<?php

$mysqli = new mysqli('localhost', 'eridder', 'eR830303896', 'eridder')
or die(' <h2>Could not connect to MySQL with mysqli</h2></body></html>');

echo "success";

$lgins = array(
		
		"CREATE TABLE IF NOT Exists ekkuser (UserId INT primary key, UserName CHAR(25), UserPIN VARCHAR(50), " .
		"NameFirst CHAR(25), NameLast CHAR(25), UserEmail VARCHAR(50), UserPhone INT);",
		
		
		"INSERT INTO ekkuser(UserId, UserName, UserPIN, NameFirst, NameLast, UserEmail, UserPhone)".
		" Values (10001, 'TestA','Apz123#','Test','Account', 'test@email.com', 5555555555);");
		
		foreach  ($lgins as $lgin){
			echo $lgin;
		
			$mysqli->query($lgin) or die('Query failed: ' . $mysqli->error . '<br>');
		}
		
		
		require("proj1/db.inc.end.php");		
		
		
?>