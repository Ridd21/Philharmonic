<?php
mysqli_close($mysqli);
$rs->free_result();
?>