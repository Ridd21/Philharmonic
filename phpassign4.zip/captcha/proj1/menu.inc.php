<nav id="menu">
	<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="AboutUs.php">About</a></li>
		<li><a href="list.php">Products</a></li>
		<li><a href="contact2.php">Contact</a></li>
		<li><a href="login.php">Login</a></li>
	</ul>
</nav> <!-- end nav -->
