<?php
$mysqli = new mysqli('localhost', 'eridder', 'eR830303896', 'eridder')
or die(' <h2>Could not connect to MySQL with mysqli</h2></body></html>');
?>