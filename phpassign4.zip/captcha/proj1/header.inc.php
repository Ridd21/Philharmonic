<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<link rel="stylesheet"	type="text/css"	href="style1.css" >
	<link rel="stylesheet"	type="text/css"	href="style2.css" media="only screen and (min-width: 780px)  ">
	<link rel="stylesheet"  type="text/css" href="print.css" media="print" >
	<link rel="stylesheet"	type="text/css"	href="mobile.css" media="only screen and (max-width: 779px) " >
</head>
<body>
<div id="layout">
<div id="header">
	<div id="logo">
 		<h1>Ekklesia <br> Coffee Co.</h1>
 	</div><!--end logo -->
 	<div id="tagline">
		<p>Keeping Coffee Classy</p>
	</div> <!-- end tagline -->
</div> <!-- end header -->