<div id="footer">
	<footer>Copyright 2015 by Emily Ridder</footer>
</div> <!-- end footer -->