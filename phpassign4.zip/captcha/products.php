<!DOCTYPE html >
<html>
<head>
	<?php $title = "Ekklesia Coffee Co.";?>
	<!-- do php variables need php tags since the file is formatted as php already? -->
		
		
	<style type="text/css"> 
			/* Colors: 
		Primary: #603018
		Secondary: #007818
		Accent: #FFFFCC 
		*/

/* Order Link Style */

	
span.links {
	background-color: #007818;
	border: 2px outset #007518;
	

	-moz-border-radius: 20px;
	-webkit-border-radius: 20px;
	border-radius: 20px;
	
	font-size: 12px;
	display: block;
	height: 20px;
	line-height: 20px;
	margin: 0px 5px 0px 5px;
	padding: 3px 10px 3px 10px;
	text-align: center;
}
	
span.links a {
	color: #FFFFCC;
	font-weight: bold;
	display: block;
	text-decoration: none;
	padding: 3px 10px 3px 10px;
}

span.links:hover {
	background-color: #FFFFCC;
}

span.links:hover a{
	color: #007518;
}

/* listTable Styles*/

table.listTable {
	font-size: 12px;
	margin: 0px 15% 30px 15%;
	width: 70%;
	border-collapse: collapse;
	background-image: url(beanwm.png);
	background-repeat: no-repeat;
	
	
}

caption  {
	font-size: 20px;
	font-weight: bold;
	padding-bottom: 20px;
	color: #603018;
	
}

/* Column Styles*/

col.firstColumn {
	background-image: url(left.jpg);
	background-position: left top;
	background-repeat:repeat-y;
	width: 22%;
}

col.middleColumn1 {
	background-image: url(blank.gif);
	background-repeat:repeat;
	width: 40%;
}

col.middleColumn2 {
	background-image: url(blank.gif);
	background-repeat:repeat;
	width: 16%;
}

col.lastColumn {
	background-image: url(right.jpg);
	background-position: right top;
	background-repeat:repeat-y;

	width: 22%;
}

/* Table row styles */

thead tr {
	background-color: #603018;
	background-image: url(top.gif);
	background-position: left top;
	background-repeat: repeat-x;
	border-bottom: 2px gray solid;
}

tfoot tr {
	background-color: #603018;
	background-image: url(bottom.gif);
	background-position: left bottom;
	background-repeat: repeat-x;

	border-top: 2px gray solid;
	text-align: center;
}

tbody tr{
	border: 1px gray dotted;
}

/* Table cell styles*/

thead th {
	letter-spacing: 2px;
}

th, td {
	padding-top: 0px;
	padding-left: 5px;
	padding-right: 5px;
	height: 30px;
}

thead tr th:first-of-type {
	background-color: #603018;
	background-image: url(topleft.gif);
	background-position: top left;
	background-repeat: no-repeat;
}

thead tr th:last-of-type {
	background-color: #603018;
	background-image: url(topright.gif);
	background-position: top right;
	background-repeat: no-repeat;
}

tfoot tr td:first-of-type {
	background-color: #603018;
	background-image: url(bottomleft.gif);
	background-position: bottom left;
	background-repeat: no-repeat;
}

tfoot tr td:last-of-type {
	background-color: #603018;
	background-image: url(bottomright.gif);
	background-position: bottom right;
	background-repeat: no-repeat;
}

	</style>
	
<?php require("proj1/header.inc.php");?>


<?php require("proj1/menu.inc.php");?>

<div id="content">
		<table class="listTable"
			summary="Ekklesia products">
	
		<caption>Roasts &amp; Such</caption>
			
		
			<colgroup>
				<col class="firstColumn"/>
				<col class="middleColumn1"/>
				<col class="middleColumn2"/>
				<col class="lastColumn"/>
			</colgroup>
			
			<thead>
			  <tr>
				<th></th>
				<th>Item</th>
				<th>Price</th>
				<th>Order</th>
			  </tr>
			</thead>
			
			<tfoot>
			  <tr>
			  	<td></td>
			  	<td colspan="2">Contact us for current roast information!</td>
			  	<td></td>
			  </tr>
			</tfoot>
			
			<tbody>
			<tr>
				<td><img src="wholebeansm.png" alt="star12.gif"/></td>
				<td>Whole Bean Coffee (per lb.)</td>
				<td>$13.00</td>
				<td><span class="links"><a href="#">Order</a></span></td>
			</tr>
			
			<tr>
				<td><img src="mugsm.png" alt="star12.gif"/></td>
				<td>Ceramic Coffee Mug</td>
				<td>$15.00</td>
				<td><span class="links"><a href="#">Order</a></span></td>
			</tr>
			
			<tr>
				<td><img src="travelhotsm.png" alt="star12.gif"/></td>
				<td>Hot Coffee Travel Thermos</td>
				<td>$25.00</td>
				<td><span class="links"><a href="#">Order</a></span></td>

			</tr>
			
			<tr>
				<td><img src="icedmugsm.png" alt="star12.gif"/></td>
				<td>Iced Coffee Travel Cup</td>
				<td>$20.00</td>
				<td><span class="links"><a href="#">Order</a></span></td>
			</tr>
			
			</tbody>
			
		</table>
</div> <!-- end content-->

<?php require("proj1/footer.inc.php");?>
</div> <!-- end layout -->
</body>
</html>