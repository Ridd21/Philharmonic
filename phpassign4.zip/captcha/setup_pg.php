<?php
$mysqli = new mysqli('localhost', 'eridder', 'eR830303896', 'eridder')
or die(' <h2>Could not connect to MySQL with mysqli</h2></body></html>');

echo "success";

$qrys = array(
		"CREATE TABLE IF NOT Exists ekkcategory (CategoryId INT primary key, CategoryName CHAR(25), " .
		"ProductThumb CHAR(50));",
		
		"CREATE TABLE IF NOT Exists ekkdesc (ProductId INT primary key, CategoryId INT, ProductName CHAR(60)," .
		"ProductDesc CHAR(255), ProductImage  CHAR(50), ProductThumb CHAR(50), BundleUnit INT, Price DECIMAL(10,2));",
		
		"INSERT INTO ekkcategory(CategoryId, CategoryName, ProductThumb) Values (1234, 'Coffee','wholebeansm.png'); ",
		"INSERT INTO ekkcategory(CategoryId, CategoryName, ProductThumb) Values (1235, 'Ceramic Mug','mugsm.png'); ",
		"INSERT INTO ekkcategory(CategoryId, CategoryName, ProductThumb) Values (1236, 'Iced Travel Cup','travelhotsm.png'); ",
		"INSERT INTO ekkcategory(CategoryId, CategoryName, ProductThumb) Values (1237, 'Hot Travel Cup','icedmugsm.png'); ",
		
//coffee bean inserts
		"INSERT INTO ekkdesc(ProductId, CategoryId, ProductName, ProductDesc, ProductImage, ProductThumb, BundleUnit, Price)
			Values (98748, 1234, 'Whole Bean Coffee per .lb','Roasted on demand to ensure the best quality is delivered to your doorstep.
			Do not forget to grind the beans before brewing coffee!','poundocoffee.jpg','wholebeansm.png', 1, 13.00 );",
		
		
		"INSERT INTO ekkdesc(ProductId, CategoryId, ProductName, ProductDesc, ProductImage, ProductThumb, BundleUnit, Price)
			Values (98749, 1234, 'Whole Bean Coffee per 5 .lbs','Roasted on demand to ensure the best quality is delivered to your doorstep.
			Do not forget to grind the beans before brewing coffee!  We recommend this size only be ordered if it will be used within 2 weeks.
			','poundocoffee.jpg','wholebeansm.png', 5, 55.25 );",
		
		"INSERT INTO ekkdesc(ProductId, CategoryId, ProductName, ProductDesc, ProductImage, ProductThumb, BundleUnit, Price)
			Values (98750, 1234, 'Whole Bean Coffee per 10 .lbs','Roasted on demand to ensure the best quality is delivered to your doorstep.
			Do not forget to grind the beans before brewing coffee!  We recommend this size only be ordered if it will be used within 2 weeks.
			','poundocoffee.jpg','wholebeansm.png', 10, 104.00 );",
		
//ceramic insert		
		
		"INSERT INTO ekkdesc(ProductId, CategoryId, ProductName, ProductDesc, ProductImage, ProductThumb, BundleUnit, Price)
			Values (98745, 1235, 'Single Mug','An old time favorite, the classic coffee mug.  This mug is crafted with a special glaze that
			keeps the mug from developing coffee ring stains like the average mug.','mug.png','mugsm.png', 1, 15.00 );",
		
		"INSERT INTO ekkdesc(ProductId, CategoryId, ProductName, ProductDesc, ProductImage, ProductThumb, BundleUnit, Price)
			Values (98746, 1235, '25 Count Mug','An old time favorite, the classic coffee mug.  This mug is crafted with a special glaze that
			keeps the mug from developing coffee ring stains like the average mug.  A 25 count selection can satisfy the needs
			of a small office or large home of coffee lovers.','mug.png','mugsm.png', 25, 337.50 );",
		
		"INSERT INTO ekkdesc(ProductId, CategoryId, ProductName, ProductDesc, ProductImage, ProductThumb, BundleUnit, Price)
			Values (98747, 1235, '50 Count Mug','An old time favorite, the classic coffee mug.  This mug is crafted with a special glaze that
			keeps the mug from developing coffee ring stains like the average mug.  A 50 count selection can satisfy the needs
			of a small-medium sized office of coffee lovers.','mug.png','mugsm.png', 50, 650.00 );",
		
		
//		travel Thermos insert

		"INSERT INTO ekkdesc(ProductId, CategoryId, ProductName, ProductDesc, ProductImage, ProductThumb, BundleUnit, Price)
			Values (98751, 1237, 'Single Travel Thermos','Made out of 100% recycled material, our thermos has a lid that locks tightly and features a sealable mouthpiece.
			Now you can enjoy your fresh brew on the go!', 'travelmughot.png', 'travelhotsm.png',1, 25.00);",
		
		"INSERT INTO ekkdesc(ProductId, CategoryId, ProductName, ProductDesc, ProductImage, ProductThumb, BundleUnit, Price)
			Values (98752, 1237, '10 Count Travel Thermos','Made out of 100% recycled material, our thermos has a lid that locks tightly and features a sealable mouthpiece.
			Now you can enjoy your fresh brew on the go! The 10 count selection is ideal for stocking stuffers, or perfect for bridal parties.',
			'travelmughot.png', 'travelhotsm.png',10, 200.00);",
		
		"INSERT INTO ekkdesc(ProductId, CategoryId, ProductName, ProductDesc, ProductImage, ProductThumb, BundleUnit, Price)
			Values (98753, 1237, '15 Count Travel Thermos','Made out of 100% recycled material, our thermos has a lid that locks tightly and features a sealable mouthpiece.
			Now you can enjoy your fresh brew on the go!  The 15 count selection is perfect for small thank you's to your coffee loving staff. ', 
			'travelmughot.png', 'travelhotsm.png',15, 281.25);",
		
// Iced mug insert

		
		"INSERT INTO ekkdesc(ProductId, CategoryId, ProductName, ProductDesc, ProductImage, ProductThumb, BundleUnit, Price)
			Values (98754, 1236, 'Single Iced Travel Cup','Made out of 100% recycled material, our travel cup features a grip to keep your hands from getting wet and cold. 
			Our uniquely designed straw flares out at the bottom to help stir ingredients when ice is mixed with the drink.', 'icedmug.png', 'icedmugsm.png', 1, 20.00);",
		
		"INSERT INTO ekkdesc(ProductId, CategoryId, ProductName, ProductDesc, ProductImage, ProductThumb, BundleUnit, Price)
			Values (98755, 1236, '10 Count Iced Travel Cup','Made out of 100% recycled material, our travel cup features a grip to keep your hands from getting wet and cold.
			Our uniquely designed straw flares out at the bottom to help stir ingredients when ice is mixed with the drink.  Consider our 10 count selection for your Cheer Squad
			or for party favors!', 'icedmug.png', 'icedmugsm.png', 10, 180.00);",
		
		"INSERT INTO ekkdesc (ProductId, CategoryId, ProductName, ProductDesc, ProductImage, ProductThumb, BundleUnit, Price)
			Values (98756, 1236, '15 Count Iced Travel Cup','Made out of 100% recycled material, our travel cup features a grip to keep your hands from getting wet and cold.
			Our uniquely designed straw flares out at the bottom to help stir ingredients when ice is mixed with the drink.  Our 15 count selection is perfect for family barbecues
			in the Summer - drinks are kept cold, glassware is kept safe in the house, and bugs can't take a dip in your beverage!', 'icedmug.png', 'icedmugsm.png', 15, 240.00);");

foreach  ($qrys as $qry){
	echo $qry;

$mysqli->query($qry) or die('Query failed: ' . $mysqli->error . '<br>');
}


require("proj1/db.inc.end.php");
/* 
$sqry = "Select * from ekkdesc;";
		$rs = $mysqli->query($sqry);
		while($row = $rs->fetch_assoc())
		{//Send specific data values to broswer
			echo $row["ProductName"];
		} 
 */


?>


if session variable is set then show the my account if the session variable is not set then show the log in button
Select * from item

to compare the user entry to the db you have to use an if statment and use the string compare, if it 
