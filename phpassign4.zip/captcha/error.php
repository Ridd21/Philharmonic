

<!DOCTYPE html >
<html>
<head>
<?php $title = "Ekklesia Coffee Co.";?>

<?php require("proj1/header.inc.php");?>


<?php require("proj1/menu.inc.php");?>
<div id="content">

<?php echo "Sorry, that action isn't allowable!";?>




</div> <!-- end content-->

<?php require("proj1/footer.inc.php");?>
</div> <!-- end layout -->
</body>
</html>