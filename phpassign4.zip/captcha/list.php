<!DOCTYPE html >
<html>
<head>
	<?php $title = "Ekklesia Coffee Co.";?>

		
		
	<style type="text/css"> 
			/* Colors: 
		Primary: #603018
		Secondary: #007818
		Accent: #FFFFCC 
		*/

/* Order Link Style */

	
span.links {
	background-color: #007818;
	border: 2px outset #007518;
	

	-moz-border-radius: 20px;
	-webkit-border-radius: 20px;
	border-radius: 20px;
	
	font-size: 12px;
	display: block;
	height: 20px;
	line-height: 20px;
	margin: 0px 5px 0px 5px;
	padding: 3px 10px 3px 10px;
	text-align: center;
}
	
span.links a {
	color: #FFFFCC;
	font-weight: bold;
	display: block;
	text-decoration: none;
	padding: 3px 10px 3px 10px;
}

span.links:hover {
	background-color: #FFFFCC;
}

span.links:hover a{
	color: #007518;
}

/* listTable Styles*/

table.listTable {
	font-size: 12px;
	margin: 0px 15% 30px 15%;
	width: 70%;
	border-collapse: collapse;
	background-image: url(beanwm.png);
	background-repeat: no-repeat;
	
	
}

caption  {
	font-size: 20px;
	font-weight: bold;
	padding-bottom: 20px;
	color: #603018;
	
}

/* Column Styles*/

col.firstColumn {
	background-image: url(left.jpg);
	background-position: left top;
	background-repeat:repeat-y;
	width: 22%;
}

col.middleColumn1 {
	background-image: url(blank.gif);
	background-repeat:repeat;
	width: 40%;
}

col.middleColumn2 {
	background-image: url(blank.gif);
	background-repeat:repeat;
	width: 16%;
}

col.lastColumn {
	background-image: url(right.jpg);
	background-position: right top;
	background-repeat:repeat-y;

	width: 22%;
}

/* Table row styles */

thead tr {
	background-color: #603018;
	background-image: url(top.gif);
	background-position: left top;
	background-repeat: repeat-x;
	border-bottom: 2px gray solid;
}

tfoot tr {
	background-color: #603018;
	background-image: url(bottom.gif);
	background-position: left bottom;
	background-repeat: repeat-x;

	border-top: 2px gray solid;
	text-align: center;
}

tbody tr{
	border: 1px gray dotted;
}

/* Table cell styles*/

thead th {
	letter-spacing: 2px;
}

th, td {
	padding-top: 0px;
	padding-left: 5px;
	padding-right: 5px;
	height: 30px;
}

thead tr th:first-of-type {
	background-color: #603018;
	background-image: url(topleft.gif);
	background-position: top left;
	background-repeat: no-repeat;
}

thead tr th:last-of-type {
	background-color: #603018;
	background-image: url(topright.gif);
	background-position: top right;
	background-repeat: no-repeat;
}

tfoot tr td:first-of-type {
	background-color: #603018;
	background-image: url(bottomleft.gif);
	background-position: bottom left;
	background-repeat: no-repeat;
}

tfoot tr td:last-of-type {
	background-color: #603018;
	background-image: url(bottomright.gif);
	background-position: bottom right;
	background-repeat: no-repeat;
}

	</style>
	
<?php require("proj1/header.inc.php");?>


<?php require("proj1/menu.inc.php");?>

<?php require("proj1/db.inc.php");?>

<div id="content">
<h2>Roasts & Such</h2>
 <table border=0 cellpadding=5 cellspacing=0 >





	<?php 
	$qry = "Select * from ekkcategory;";
	$rs = $mysqli->query($qry);
	// Loop through results set
	while($row = $rs->fetch_Assoc())
	{ // Send Specific Data values to Browser
	?>
	<tr>
	 <td width="80">
	   <img src="<?php echo $row["ProductThumb"]; ?>" 
	        width="80" height="80"></td>
	 <td><?php echo $row["CategoryName"]; ?></td>
	<td><a href='details.php?id=<?php echo $row["CategoryId"]; ?>'>Order</a></td></tr>
	<?php 
	} // end of while loop
	require("proj1/db.inc.end.php");
	 echo "</table>"; 
	?> 
	
	
	
<!-- 
	
	echo "<table>";
	
	while($row = $rs->fetch_Assoc())
	{//send specific data values to browser
		echo "<tr><td>".$row["CategoryName"]."</td><td>".$row["ProductThumb"]."</td><td>
					<a href='details.php?id=CategoryId'>Order</a></td></tr>";
	}
				
	echo "</table>";
	
	
	?> -->
		
<a href=details.php?id=<?php echo $row["CategoryId"]; ?>>	
		
		
		
</div> <!-- end content-->

<?php require("proj1/footer.inc.php");?>
</div> <!-- end layout -->
</body>
</html>