
<!DOCTYPE html >
<html>
<head>
<?php $title = "Ekklesia Coffee Co.";?>
	</script>
<!-- Styles -->

<style type="text/css">

fieldset {
	background-color: #FFFBF3;
	border-color: #894828;
	padding: 10px;
	margin-bottom: 10px;}

fieldset span {
	color: red;}
fieldset span error {
	color: red;}

label.blockLabel {
	display: block;
	position: relative;
	margin: 12px 0px 12px 0px;
	width: 450px;}


.blockLabel input{
	position:absolute;
	left: 140px;}

#uName, #uPIN {
	width: 250px;}

</style>



<?php require("proj1/header.inc.php");?>

<?php require("proj1/menu.inc.php");?>


<?php

// define variables and set to empty values
/* $uNameErr = $uPINErr = "";
$uName = $uPIN = ""; */

if(!isset($_GET["uName"]))
		header('Location:error.php');
		
 require("proj1/db.inc.php");
	$qry="Select * from lgins WHERE UserName LIKE".$_GET["uName"]."AND UserPIN LIKE".$_GET["uPIN"].";";
	$rs=$mysqli->query($qry);
	
	if($rs->fetch_assoc()){
	echo '<p> You are logged in!</p>';
	}else{
		echo "error";
		echo htmlspecialchars($_SERVER["PHP_SELF"];
	}
	
?>





<div id="content">
	<form name="loginForm" id="loginForm" method="post" action="<?php if(echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" >
<h2>Login</h2>

	<fieldset id="loginFields">
		<legend>Credentials</legend>
			<label class="blockLabel" for="uName">User Name <span>*</span> 
			<input name="uName" id="uName" type="text"> </label>
						
			<label class="blockLabel" for="uPIN">Password <span>*</span> 
			<input name="uPIN" id="uPIN" type="text"> </label>
	
			
	</fieldset>		
	
	<br/>
	<p>
		<input type="submit" value="Login"/>
		<input type="reset" value="Cancel"/>
	</p>
	
	</form>
<?php /* require("proj1/db.inc.end.php"); */?>

</div> <!--  end content -->
<?php require("proj1/footer.inc.php");?>
</div> <!-- end layout -->
</body>
</html>