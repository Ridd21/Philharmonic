<?php
header("Content-type: text/javascript");
require("proj1/db.inc.php");

$output = "";

$qry = "SELECT * FROM ekkdesc WHERE CategoryId=" .$id. ";";
$rs = $mysqli->query($qry)  or die('Query failed: ' . $mysqli->error . '<br>');
$rows = array();
while($row = $rs->fetch_assoc()) {
	array_push($rows,$row);
}
$output = json_encode($rows);
echo $output;
require("proj1/db.inc.end.php");
?>