<!DOCTYPE html >
<html>
<head>
	<?php $title = "About Ekklesia Coffee Co."; ?>
	<?php require("proj1/header.inc.php");?>
    <?php require("proj1/menu.inc.php");?>


<div id="content">
	<h2>About Us</h2>
	
		<p> It's not every day that you get a simple group of gentlemen who all share in one love, coffee.  Our taste in coffee is so unique, we started to roast
		beans for ourselves.  Inviting our female friends over for a cup of coffee was possibly the best move we could have ever made.  Word spread like wildfire, 
		the whispers of that 'fabulous cup of coffee at Tim's house' turned into a roar.  We felt the ability to identify a good bean, and roast it to perfection, 
		was a gift better shared with the world.  And share we did.  December 2014 saw the dawn of our brain child (or is it taste child?), Ekklesia Coffee Co., a 
		small roasting company based in Lakewood, Colorado.
		</p>
		<p class="center"> 
		<img src="Team.jpg" alt="About Us Ekklesia Coffee Co." height="225"  width="350"> </p >
		<p>Ekklesia Coffee Co. orders beans straight from Ethiopia, a location known for its coffee bean farming community.  Ekklesia takes micro-roasting to 
		a whole new level.  Every day, beans are roasted by the pound, as they are ordered - proving that we are providing the freshest product available.
		</p>
	<h3><span>Ring Leaders</span></h3>	
<!-- 	<ul>
		<li><strong>Paul Ji</strong> - Co Founder</li>
		<li><strong>Matt Rendall</strong> - Co Founder</li>
		<li><strong>Tim Rendall</strong> - Co Founder</li>
		<li><strong>Mason Price</strong> - Co Founder</li>
		<li><strong>Emily Ridder</strong> - Web Developer</li>
	</ul>	 -->
		<ul>
		<?php 
		$people = array("Paul Ji" => "Co Founder",
				"Matt Rendall" =>  "Co Founder",
				"Tim Rendall" =>  "Co Founder",
				"Mason Price" =>  "Co Founder",
				"Emily Ridder" => "Web Developer");
				
		
		foreach($people as $person => $wTitle) {
			echo "<li>".$person . " - " . $wTitle . "</li>". "<br/>";
		}
				
		?>
				
	</ul>
</div> <!-- end content -->

<?php require("proj1/footer.inc.php");?>
</div> <!-- end layout -->
</body>
</html>