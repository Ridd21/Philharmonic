<!DOCTYPE html >
<html>
<head>
	<?php $title = "Ekklesia Coffee Co."; ?>
	<?php require("proj1/header.inc.php");?>
    <?php require("proj1/menu.inc.php");?>

<div id="content">
	<h2>Micro-Roasted, Maximum Flavor, Minimum Cost</h2>
	<p>Ekklesia Coffee Co. is an order based micro coffee roaster, specializing in easily accessible no frills coffee.  To ensure maximum quality product,
	we opted to have our beans shipped straight from the source - this route is more expensive than what most coffee houses purchase, but we promise your
	wallet won't feel a thing. It's our mission to create fresh, high quality, roasts that will titilate your tastebuds more than your average cup o' jo.</p>
	<p class="center">
	<img src="Logo.jpg" alt="Ekklesia Coffee Co." height="250" width="400"></p>
</div> <!-- end content-->

<?php require("proj1/footer.inc.php");?>
</div> <!-- end layout -->
</body>
</html>