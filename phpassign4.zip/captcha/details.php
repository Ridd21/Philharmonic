<?php
/* 
 * This is my code to add the error file, I don't know how else to call the file.  catch & throw?  Also,  I did some editing
to picture names since I referred to all of them incorrectly in my db but was unable to fix all of the problems.  I will most likely drop
my db and recreate w/ Dr. Gregg's help.
 * error_reporting(E_ALL);
ini_set("display_errors",1);
include ("error.php"); */  redirect header:location
?>

<!DOCTYPE html >
<html>
<head>
<?php $title = "Ekklesia Coffee Co.";?>


<?php require("proj1/header.inc.php");?>

<?php require("proj1/menu.inc.php");?>

<?php require("proj1/db.inc.php");?>


<?php 
$id = $_GET["id"];

$qry = "SELECT * FROM ekkcategory WHERE CategoryId= " .$id. ";";
$rs = $mysqli ->query($qry)
 or die('Query1 failed:' . $mysqli->error . '<br>');
$row = $rs->fetch_assoc();
$cname = $row["CategoryName"];



$qry = "SELECT * FROM ekkdesc WHERE CategoryId=" .$id. ";";
//echo $qry;
$rs = $mysqli->query($qry)
or die('Query2 failed: ' .$mysqli->error . '<br>');
$row = $rs-> fetch_assoc();

 $iname = $row["ProductName"];
 $iimg = $row["ProductImage"];
 $idesc = $row["ProductDesc"];
 
 
 echo "<title>".$iname. ": ". $cname."</title>";

/* $qry = "SELECT * FROM ekkdesc WHERE ProductId=" . $item . ";";
$rs = $mysqli -> query($qry)
 or die('Query2 failed: ' . $mysqli->error . '<br>');
 $row = $rs-> fetch_assoc();
 
 $iname = $row["ProductName"];
 $iimg = $row["ProductImage"];
 $idesc = $row["ProductDesc"];

 echo "<title>".$iname. ": ". $cname."</title>";
 */

?>


<div id="content">

 
 
<h2><span><?php echo $cname;?></span></h2>
<table style= 'width:80%; margin: auto;'>
<tr>
	<td><img src= <?php echo $iimg;?>
	WIDTH=240 HEIGHT=180 ALIGN=RIGHT></td>
	<td><h3><?php echo $iname;?></h3>
	<?php echo $idesc;?></td>
	
	</tr>

</table>


<form NAME ='frmOrderItems'>
<table style='width:80%; margin: auto;' class='listTable'>
<caption>Order Items</caption>
<thead>
<tr>
<th style='width:20%; text-align: center'>Selection</th>
<th style='width:20%; text-align: center'>BundleUnit</th>
<th style='width:20%; text-align: center'>Price</th>
<th style='width:20%; text-align: center'>In Stock?</th>

</tr>
</thead>

<tbody>
<?php 
$qry = "SELECT * FROM ekkdesc WHERE CategoryId=" .$id. ";";
//echo $qry;
$rs = $mysqli->query($qry)
or die('Query3 failed: ' .$mysqli->error . '<br>');
$counter = 0;
while($row = $rs->fetch_assoc()){
	$quant = $row["BundleUnit"];
	$pr = $row["Price"];
	echo "<tr style= 'text-align:center;'>";
	echo "<td><input type='radio' checked='checked' name='item' value='".$quant."|".$pr."'></td><td>".$quant."</td>";
	echo "<td>".$pr."</td><td>Yes</td></tr>";
}

?>
</tbody>
</table>
<br/>



<?php require("proj1/db.inc.end.php");?>

</div> <!-- end content-->

<?php require("proj1/footer.inc.php");?>
</div> <!-- end layout -->
</body>
</html>