
<?php

// define variables and set to empty values
$uNameErr = $uPINErr = "";
$uName = $uPIN = "";



/* 

if (isset($_POST['submit'])) { */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if (empty($_POST["uName"])) {
		$uNameErr = "User Name is required";
	} else {
		$uName = test_input($_POST["uName"]);
	}

	if (empty($_POST["uPIN"])) {
		$uPINErr = "Password is required";
	} else {
		$uPIN = test_input($_POST["uPIN"]);
	}}
		
		
function test_input($data) {
			$data = trim($data);
			$data = stripslashes($data);
			$data = htmlspecialchars($data);
			return $data;
		}
		
else
		{require("proj1/db.inc.php");		
		$qry = "SELECT * FROM lgins WHERE UserPIN ='$uPIN' AND UserName='$uName'";

			$_SESSION['login_user']=$uName; // Initializing Session
			header("location: login_trans.php"); // Redirecting To Other Page
		} else {
			$error = "Username or Password is invalid";
		}
		require("proj1/db.inc.end.php"); // Closing Connection
		}
		} 
		
		
?>


<!DOCTYPE html >
<html>
<head>
<?php $title = "Ekklesia Coffee Co.";?>
	</script>
<!-- Styles -->

<style type="text/css">

fieldset {
	background-color: #FFFBF3;
	border-color: #894828;
	padding: 10px;
	margin-bottom: 10px;}

fieldset span {
	color: red;}
fieldset span error {
	color: red;}

label.blockLabel {
	display: block;
	position: relative;
	margin: 12px 0px 12px 0px;
	width: 450px;}


.blockLabel input{
	position:absolute;
	left: 140px;}

#uName, #uPIN {
	width: 250px;}

</style>



<?php require("proj1/header.inc.php");?>

<?php require("proj1/menu.inc.php");?>


<div id="content">
	<form name="loginForm" id="loginForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" >
<h2>Login</h2>

	<fieldset id="loginFields">
		<legend>Credentials</legend>
			<label class="blockLabel" for="uName">User Name <span>*</span> 
			<input name="uName" id="uName" type="text"> </label>
			<span class="error"><?php echo $uNameErr;?></span><br><br>
			
			
			<label class="blockLabel" for="uPIN">Password<span>*</span> 
			<input name="uPIN" id="uPIN" type="text"> </label>
			<span class="error"><?php echo $uPINErr;?></span><br><br>
			
	</fieldset>		
	
	<br/>
	<p>
		<input type="submit" value="Login"/>
		<input type="reset" value="Cancel"/>
	</p>
	
	</form>


</div> <!--  end content -->
<?php require("proj1/footer.inc.php");?>
</div> <!-- end layout -->
</body>
</html>