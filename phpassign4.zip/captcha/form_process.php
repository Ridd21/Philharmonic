
<!DOCTYPE html >
<html>
<head>
	<?php $title = "Contact Ekklesia Coffee Co." ; ?>

	<?php require("proj1/header.inc.php");?>
    <?php require("proj1/menu.inc.php");?>

<div id="content">
	
	<p> Thank you, <?php echo $_POST['fName']; ?>, for visiting have a fabulous day! </p>
	
	<p class="center">
	<img src="Logo.jpg" alt="Ekklesia Coffee Co." height="250" width="400"></p>
	
	

</div> <!-- end content-->


<?php 


$handle = fopen('comsubmit.csv','a');//code isn't appending what I am resubmitting - might be pulling from cache
fwrite($handle, $_POST['fName']);
fwrite($handle, $_POST['lName']);
fwrite($handle, $_POST['email']);
fwrite($handle, $_POST['questions']);
fclose($handle);//is this needed?


require("proj1/footer.inc.php");
?>
</div> <!-- end layout -->
</body>

</html>